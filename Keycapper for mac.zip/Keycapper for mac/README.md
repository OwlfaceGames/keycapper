# README
Note: the included fonts must remain in the same folder as the binary. Also as the mac version is just a unix binary it must be ran from the command line with ./keycapper from the folder that the binary is in.
