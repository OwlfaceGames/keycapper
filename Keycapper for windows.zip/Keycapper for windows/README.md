# README
Note: the included fonts and dlls must remain in the same folder as the binary in order for the program to work on windows.
